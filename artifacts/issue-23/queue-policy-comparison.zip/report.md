# RoverEdge experiment evidence

This report is generated from the machine-readable evidence in this bundle.
Unavailable measurements are reported as not recorded rather than inferred.

## Comparison

- Kind: `controlled`
- Valid: `true`
- Declared factor: `configuration.modeled_device.queue_policy`
- Changed request paths: `configuration.modeled_device.queue_policy`
- Validity: only declared factor configuration.modeled_device.queue_policy changed
- Interpretation: one declared factor changed; the comparison can test that factor but does not by itself establish causality

## Run 1: `54e10deb-f371-42e7-b705-cc3ca4a3d1a5`

- Scenario: `preset-open-v2`
- Simulation seed: `20261027`
- Mission outcome: `timed_out`
- Test verdict: `passed`
- Controller: `learned_collision_risk`
- Inference backend: `python-reference`
- Model version: `risk-model-v1`
- Model SHA-256: `d4c43e7738508bb59a7ba87720b6f32b876a5270bf437f17988a9340e18ad2d9`
- Timing provenance: `modeled`
- Terminal reason: mission exceeded its simulated-time limit
- Trace samples: `625`
- Inspection observations: `0`

### Inference and queue metrics

- `admitted`: `6`
- `admitted_total`: `20`
- `completed`: `13`
- `consumed`: `6`
- `current_modeled_memory_bytes`: `18948`
- `deadline_misses`: `13`
- `dropped`: `3`
- `dropped_total`: `35`
- `execution_mode`: `virtual_fifo`
- `expired`: `11`
- `in_flight_payload_bytes`: `0`
- `memory_budget_bytes`: `32768`
- `memory_rejected`: `0`
- `memory_rejections`: `0`
- `overflow`: `21`
- `peak_modeled_memory_bytes`: `22020`
- `pending_payload_bytes`: `0`
- `replaced`: `0`
- `resident_weights_bytes`: `14852`
- `scheduled`: `41`
- `timing_provenance`: `modeled`
- `workspace_bytes`: `4096`

## Run 2: `b72a84a3-bfd8-49ca-b6ca-1fffd36da113`

- Scenario: `preset-open-v2`
- Simulation seed: `20261027`
- Mission outcome: `timed_out`
- Test verdict: `passed`
- Controller: `learned_collision_risk`
- Inference backend: `python-reference`
- Model version: `risk-model-v1`
- Model SHA-256: `d4c43e7738508bb59a7ba87720b6f32b876a5270bf437f17988a9340e18ad2d9`
- Timing provenance: `modeled`
- Terminal reason: mission exceeded its simulated-time limit
- Trace samples: `671`
- Inspection observations: `0`

### Inference and queue metrics

- `admitted`: `1`
- `admitted_total`: `41`
- `completed`: `13`
- `consumed`: `13`
- `current_modeled_memory_bytes`: `18948`
- `deadline_misses`: `13`
- `dropped`: `2`
- `dropped_total`: `28`
- `execution_mode`: `virtual_fifo`
- `expired`: `0`
- `in_flight_payload_bytes`: `0`
- `memory_budget_bytes`: `32768`
- `memory_rejected`: `0`
- `memory_rejections`: `0`
- `overflow`: `0`
- `peak_modeled_memory_bytes`: `20996`
- `pending_payload_bytes`: `0`
- `replaced`: `26`
- `resident_weights_bytes`: `14852`
- `scheduled`: `41`
- `timing_provenance`: `modeled`
- `workspace_bytes`: `4096`

## Reproduction

The complete request configuration, expectations, traces, outcomes, and available runtime metrics are stored in the corresponding `runs/*.json` files. File hashes in `manifest.json` must pass before reproduction is attempted.
